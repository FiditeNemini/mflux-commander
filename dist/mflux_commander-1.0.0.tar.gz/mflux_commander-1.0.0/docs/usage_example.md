mflux-wrapper.py --brainstorm "magical forest" --new

mflux-wrapper.py --run-prompt 3 --landscape

mflux-wrapper.py --vary-steps 2,3,4 --seed 362394

mflux-wrapper.py --style charcoal
