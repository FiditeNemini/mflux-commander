"""
MFlux Commander - A CLI tool for managing and exploring image generation with mflux-generate.
"""

__version__ = "1.0.0" 